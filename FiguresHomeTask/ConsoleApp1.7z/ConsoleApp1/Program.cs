﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Figure f = new Figure();
            f.FigureSquare();
            f.FigureTriangle();
            f.FigureRectangle();
            f.SpaceTriangle();
            f.InSpaceTriangle();
            OutStarsTriangle Ost = new OutStarsTriangle();
            Ost.OutStars();
            Console.ReadLine();
        }

    }

}
