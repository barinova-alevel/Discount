﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class NextAttempt
    {
        public struct Contact
        {
            public int PhoneNumber { get; set; }                                                                                    
            public string FirstName { get; set; }
            public string CardType { };

            public enum CardType

            {
                Platinum,
                Gold
            }
            public string BankCard {
                
            }
            BankCard  = new BankCard();

            //public enum
            //{
            //    EmptyBankCard = ;
            //    EmptyCvvCode = 102;
            //}


            Contact[] Card = new Contact[2];
            
            phoneBook[0] Firstname = "Tim";
            phoneBook[0] CardType = "Gold";

           
            phoneBook[1] Firstname = "Don";
            phoneBook[1] Lasttname = "Platinum";

           
        }

        
    }
}
