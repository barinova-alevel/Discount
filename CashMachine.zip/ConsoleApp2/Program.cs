﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{

    class Program
    {
        static void Main(string[] args)
        {
            // EntryPointNotFoundException p1 = new EntryPointNotFoundException();
            //p1X = 10;
            //p1Y = 20;
            //Figure f = new Figure();
            //f.FigureSquare();
            //f.FigureTriangle();
            //f.FigureRectangle();
            //f.SpaceTriangle();
            //f.InSpaceTriangle();
            //OutStarsTriangle Ost = new OutStarsTriangle();
            //Ost.OutStars();
            //ConsoleApp1.Array ar = new ConsoleApp1.Array();
            //ar.ArrayOutput();
            //ar.RowNumber();
            //ar.CoulmnNumber();

            //ar.SortArray();
            //Console.ReadLine();
            // RunUserFlow();
            try
            {
                new CashMachine.CashMachine().Init();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
            }
            Console.ReadLine();
        }

        public static void RunUserFlow()
        {
            Contact[] contacts = new PhoneBook().BookInitial();
            //  phone
            string choise = string.Empty;
            do
            {
                choise = Console.ReadLine();
                //print main menu
                //PrintMain();

                switch (choise)
                {
                    case "1":
                      /// AddUser();
                        break;
                    case "2":
                       /// RemoveUser();
                        break;

                    case "3":
                        //ShowUser();
                        break;
                    
                }
            }
            while (choise == "0");
        }

    }
}